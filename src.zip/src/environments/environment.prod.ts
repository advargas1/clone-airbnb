export const environment = {
  production: true,
  urlBase: 'https://bankairbnbapp.herokuapp.com'
};
