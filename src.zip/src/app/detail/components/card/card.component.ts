import { Component, OnInit, Input } from '@angular/core';
import { IExperience } from '../../../shared/models/experience.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {

@Input() experience: IExperience;


  constructor(private route: Router) { }

  ngOnInit(): void {
  }

  public irReserva(id: string): void{
    this.route.navigate(['/booking', id]);
  }

}
