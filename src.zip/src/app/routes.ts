
import { Routes } from '@angular/router';
import { DetailComponent } from './detail/detail.component';
import { BookingComponent } from './booking/booking.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { Page404Component } from './error-page/components/page404/page404.component';
import { OnlyLoggedInUsersGuardGuard } from './shared/guards/only-logged-in-users-guard.guard';


export const routes: Routes = [
    {
    path:'',
    redirectTo: '/home',
    pathMatch: 'full'

    },
    {​​​​​
      path: 'home',
      loadChildren: () => import('./home/home.module').then(mod => mod.HomeModule)
    }​​​​​,
  
    {
      path: 'detail/:id',
      component: DetailComponent
    },

    {
      path: 'booking/:_id',
      loadChildren: () => import('./booking/booking.module').then(mod => mod.BookingModule),
      canActivate: [OnlyLoggedInUsersGuardGuard]
    },

    {
      path: 'signin',
      component: SigninComponent      
    },
    {
      path: 'signup',
      component: SignupComponent
    },
    {
      path: '404',
      component: Page404Component
    },
    {
      path: '**',
      redirectTo: '/404'
    }
  
  ];