import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { IUser } from '../../../shared/models/user.model';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../../../services/users/users.service';

@Component({
  selector: 'app-form-register',
  templateUrl: './form-register.component.html',
  styleUrls: ['./form-register.component.scss']
})
export class FormRegisterComponent implements OnInit {

  public formGroup: FormGroup;
  public userModel: IUser;

  constructor(private formBuilder: FormBuilder,    
    private route: ActivatedRoute,
    private usersService: UsersService) { }

  ngOnInit(): void {
    this.formInit();
  }

  private formInit(): void{
    this.formGroup = this.formBuilder.group({
      name: ['', Validators.required],
      phone:['',Validators.required],
      email:['@',[Validators.required,Validators.email]],
      password:['',[Validators.required, Validators.maxLength(16), this.validatePassword]]

    }) 
  }

  private validatePassword(control: AbstractControl){
    const password = control.value;
    let error = null;
    const er = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;

    if(!er.test(password)){
      error = { customError: 'debes tener al menos una mayuscula, un numero y ser minimo 8 caracteres.'};
    }

    return error;

  }

  public getError(controlName: string): string{

    let error = '';
    const control = this.formGroup.get(controlName);

    if(control.touched && control.errors != null)
    {
     error = this.errorMapping(control.errors); //control.errors.customError;
    }

    return error;
  }

  public errorMapping (errors: any){
    let errorsMessage = '';
    if(errors.required){
      errorsMessage += 'campo obligatorio.';  
    }
    if(errors.customError){
      errorsMessage += errors.customError; 
    }
    if(errors.maxlength){
      errorsMessage += `La longitud máxima debe ser ${​​​​​​​errors.maxlength.requiredLength}​​​​​​​`;
    }
    if(errors.email)
    {
      errorsMessage += 'Debes ingresar un correo valido.';  

    }
    return errorsMessage;
  }

  public register(): void{
      const data: IUser = this.formGroup.value;
      this.getParams(data);
      //console.log(data);
  }

  private getParams(data: IUser): void {
    this.route.params.subscribe(params =>{
      this.usersService.addUser(data).subscribe(response => {
        this.userModel = response;
      }); 
    }) 
    console.log(data);
  }
}
