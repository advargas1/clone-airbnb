import { Component, OnInit } from '@angular/core';
import { IUser } from '../shared/models/user.model';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../services/users/users.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {


  public userModel: IUser;

  constructor(
    private route: ActivatedRoute,
    private usersService: UsersService
  ) { }

  ngOnInit(): void {
    this.getParams();
  }

  private getParams(): void {
    this.route.params.subscribe(params =>{
      const id =params.id;
      //console.log('id',id);
     // this.experience = this.experienceService.getExperienceById(id)
    // this.experience = response.getExperiencesId(id);

    this.usersService.addUser(this.userModel).subscribe(response => {
      this.userModel = response;
    }); 

    }) 
  }

}
