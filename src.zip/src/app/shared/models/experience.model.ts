
export interface IExperience {
    _id: string;
    image: string;
    description: string;
    place: string;
    title:string;
    price?: string;
    score: number;
    users: number;
    ___v: number

}