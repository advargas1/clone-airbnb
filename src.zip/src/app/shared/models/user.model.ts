export interface IUser{

    _id?: string;
    name?:string;
    phone?:string;
    identification?: string;
    email: string;
    passsword: string;
    __v?: number;
    token?: string;
    status?: number;
}