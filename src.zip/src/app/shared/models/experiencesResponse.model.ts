import { IExperience } from './experience.model';
import { IBooking } from './booking.model';

export interface IExperienceResponse {
  experiences: Array<IExperience>;
  top5: Array<IExperience>;

  experience: IExperience;
}