import { Component, OnInit } from '@angular/core';
import { ExperienceService } from '../../../services/experience/experience.service';
import { IExperience } from '../../../shared/models/experience.model';

@Component({
  selector: 'app-ranking',
  templateUrl: './ranking.component.html',
  styleUrls: ['./ranking.component.scss']
})
export class RankingComponent implements OnInit {

  public experiences: Array<IExperience>;
  
  constructor(private experienceService: ExperienceService) { }

  ngOnInit(): void {
    this.getALLExperiences();
  }

  private getALLExperiences(): void{
    this.experienceService.getExperiencesTop5().subscribe(response => {
      this.experiences = response.top5;
    });
  }

}
