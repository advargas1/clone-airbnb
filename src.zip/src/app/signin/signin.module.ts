import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormSigninComponent } from './components/form-signin/form-signin.component';
import { SigninComponent } from './signin.component';
import { ReactiveFormsModule } from '@angular/forms'



@NgModule({
  declarations: [SigninComponent, FormSigninComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ]
})
export class SigninModule { }
