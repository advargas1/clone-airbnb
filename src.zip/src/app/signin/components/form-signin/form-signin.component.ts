import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IUser } from '../../../shared/models/user.model';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from '../../../services/users/users.service';
import { IExperience } from '../../../shared/models/experience.model';

@Component({
  selector: 'app-form-signin',
  templateUrl: './form-signin.component.html',
  styleUrls: ['./form-signin.component.scss']
})
export class FormSigninComponent implements OnInit {
  
  public formGroupSignin: FormGroup;
  public userModel: IUser;
  public datoUsuario: any;

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private usersService: UsersService,
    private router: Router) { }

  ngOnInit(): void {
    this.formInit();
  }

  private formInit(): void{
    this.formGroupSignin = this.formBuilder.group({    
      email:['@',[Validators.required,Validators.email]],
      password:['',[Validators.required, Validators.minLength(4)]]

    }) 
  }

  public register(): void{
      const data: IUser = this.formGroupSignin.value;
      this.getParams(data);
      //this.router.navigateByUrl('/booking/'); 
      this.router.navigate(['/home']);  
        
  }

  private getParams(data: IUser): void {
    this.route.params.subscribe(params =>{
      this.usersService.signin(data).subscribe(response => {
        console.log(response);
        if(response.status === 1){
          localStorage.setItem('token', response.token);  
        }  
      }); 
    }) 



    //this.datoUsuario = JSON.parse(localStorage.getItem('token'));
    //localStorage.removeItem('token');
    //localStorage.clear();

  }

}
