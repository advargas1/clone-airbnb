import { Injectable } from '@angular/core';
import { IExperience } from '../../shared/models/experience.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs'
import { retry, catchError } from 'rxjs/operators'
import { IExperienceResponse } from '../../shared/models/experiencesResponse.model';
import { environment } from './../../../environments/environment'
import { IUser } from '../../shared/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  
  private urlAPI: string = environment.urlBase;
  private isLogged: boolean = false;

  constructor(private httpClient : HttpClient) { }  

  public isLoggedUser(): boolean{
    this.isLogged = localStorage.getItem('token') ? true : false ;      
    return this.isLogged;
  }

  private handlerError(error: HttpErrorResponse){
    console.error('http error', error);
    return throwError(`Error calling api ${error.message}`);
}
 public addUser(userModel: IUser): Observable<IUser> {
    const url = `${this.urlAPI}/users/signup`;
    return this.httpClient.post<IUser>(url, userModel)
      .pipe(
        catchError(this.handlerError)
      );
  }

  public signin(userModel: IUser): Observable<IUser> {
    const url = `${this.urlAPI}/users/login`;
    return this.httpClient.post<IUser>(url, userModel)
      .pipe(
        catchError(this.handlerError)
      );
  }
}
