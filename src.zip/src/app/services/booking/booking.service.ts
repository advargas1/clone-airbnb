import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { IBooking } from '../../shared/models/booking.model';
import { catchError } from 'rxjs/operators';
import { AuthInterceptorService } from '../Interceptor/auth-interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  private urlAPI: string = environment.urlBase;

  constructor(private httpClient : HttpClient) { }

  private handlerError(error: HttpErrorResponse){
    console.error('http error', error);
    return throwError(`Error calling api ${error.message}`);
}

  public getBooking(bookingModel: IBooking): Observable<IBooking> {
    const url = `${this.urlAPI}/booking`;
    return this.httpClient.post<IBooking>(url, bookingModel)
      .pipe(
        catchError(this.handlerError)
      );
  }

}
