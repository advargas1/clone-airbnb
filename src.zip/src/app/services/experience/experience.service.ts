import { Injectable } from '@angular/core';
import { IExperience } from '../../shared/models/experience.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs'
import { retry, catchError } from 'rxjs/operators'
import { IExperienceResponse } from '../../shared/models/experiencesResponse.model';
import { environment } from './../../../environments/environment'


@Injectable({
  providedIn: 'root'
})
export class ExperienceService {

  private urlAPI: string = environment.urlBase;

  constructor(private httpClient : HttpClient) {}


  private handlerError(error: HttpErrorResponse){
      console.error('http error', error);
      return throwError(`Error calling api ${error.message}`);
  }

  public getExperiences (): Observable<IExperienceResponse> {
    const url = `${this.urlAPI}/experiences`;
    return this.httpClient.get<IExperienceResponse>(url).pipe(
      retry(2), catchError(this.handlerError)
    );
  }

  public getExperiencesTop5 (): Observable<IExperienceResponse> {
    const url = `${this.urlAPI}/experiences/top5`;
    return this.httpClient.get<IExperienceResponse>(url).pipe(
      retry(2), catchError(this.handlerError)
    );
  }

  public getExperiencesId (id:string): Observable<IExperienceResponse> {
    const url = `${this.urlAPI}/experiences/detail/${id}`;
    return this.httpClient.get<IExperienceResponse>(url).pipe(
      retry(2), catchError(this.handlerError)
    );
  }

    public getExperienceById(id:number): any{
        //return this.experiences.find(item => item.id === id)

    }

   
}
