import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor {

  constructor(private router: Router) { }


  /*intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let ContentType = 'application/json; charset=utf-8';
    let authorization = '';
    const token: string = localStorage.getItem('token');

    if (token !== null) {
        authorization = `Bearer ${token.replace(/['"]+/g, '')}`;
        console.log('prueba autorizacion token',authorization);
    }

    request = request.clone({
        setHeaders: {
            Authorization: authorization,
            "Content-Type": ContentType,
        }
    });
    return next.handle(request);
}*/

public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  
    const token: string = localStorage.getItem('token');

    let authorization = '';

    if (token !== null) {
      authorization = `Bearer ${token.replace(/['"]+/g, '')}`;     

      request = request.clone({
        setHeaders: {
          Authorization: authorization
        }
      });
    }

    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {

        if (err.status === 401) {
          this.router.navigateByUrl('/home');
        }

        return throwError( err );
      })
    );
  }


}
