import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { IBooking } from '../../../shared/models/booking.model';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../../../services/booking/booking.service';
import { IExperience } from '../../../shared/models/experience.model';
import { ExperienceService } from '../../../services/experience/experience.service';

@Component({
  selector: 'app-form-booking',
  templateUrl: './form-booking.component.html',
  styleUrls: ['./form-booking.component.scss']
})
export class FormBookingComponent implements OnInit {

  public formGroup: FormGroup;
  public bookingResponse: IBooking;

  public experience: IExperience;

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private bookingService: BookingService,
    private experienceService: ExperienceService,
    private router: Router) {}

  ngOnInit(): void {
    this.getParamsExperience();
    this.formInit();    
  }

  private formInit(): void{
    this.formGroup = this.formBuilder.group({
      /*booking_date_start: ['', [Validators.required,this.validateDate]], */     
      booking_date_start:['', [Validators.required,this.validateDate]], 
      booking_date_end:['', [Validators.required,this.validateDate]], 
      // experience_id:[''],   
      comments:['',Validators.required]
    },
    { validators: this.validateDateRange()

    }) 
  }

  private getParamsExperience(): void {
    this.route.params.subscribe(params =>{
     const id =params._id;

     this.experienceService.getExperiencesId(id).subscribe(response => {
     this.experience = response.experience;
    });

    }) 
  }

  private validateDate(control: AbstractControl){
    const sdate = new Date(control.value);
    let date = new Date();
    let error = null;

    if(sdate < date){
      error = { customError: 'la fecha debe ser mayor o igual a la actual.'};
    }
    console.log('fecha actual',date);
    return error;

  }

  private validateDateRange(){
    return (formGroup: FormGroup) => {
      const controlBookingDateStart = formGroup.controls['booking_date_start']
      const controlBookingDateEnd = formGroup.controls['booking_date_end']

      if(new Date(controlBookingDateStart.value) > new Date(controlBookingDateEnd.value)){
        controlBookingDateEnd.setErrors({mustGreaterThan: true})
      }
    }
  }

  public getError(controlName: string): string{

    let error = '';
    const control = this.formGroup.get(controlName);

    if(control.touched && control.errors != null)
    {
     error = this.errorMapping(control.errors); //control.errors.customError;
    }

    return error;
  }

  public errorMapping (errors: any){
    let errorsMessage = '';
    if(errors.required){
      errorsMessage += 'campo obligatorio.';  
    }
    if(errors.customError){
      errorsMessage += errors.customError; 
    }
    if(errors.maxlength){
      errorsMessage += `La longitud máxima debe ser ${​​​​​​​errors.maxlength.requiredLength}​​​​​​​`;
    }
    if(errors.email)
    {
      errorsMessage += 'Debes ingresar un correo valido.';  

    }

    if(errors.mustGreaterThan){
      errorsMessage += 'La fecha debe ser mayor a la fecha inicial'; 
    }
    return errorsMessage;
  }

  public register(): void{
      const data: IBooking = this.formGroup.value;
      data.experience_id = this.experience._id; 
      this.getParams(data);

      console.log('registro',data)
  }

  private getParams(data: IBooking): void {
  this.route.params.subscribe(params =>{
      this.bookingService.getBooking(data).subscribe(response => {
        this.bookingResponse = response;
      }); 
    })   
  }
  
}
